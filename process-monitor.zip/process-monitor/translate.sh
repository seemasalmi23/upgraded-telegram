#! /bin/sh

xgettext --from-code=UTF-8 --package-name=TopHat --copyright-holder="Todd Kulesza" --output=po/tophat.pot tophat@fflewddur.github.io/*.js tophat@fflewddur.github.io/lib/*.js
